# kaggle_cervical

Step #1 - data-preprocess
  Check the data folder path in ./pre_process_data/kaggle_convert_input_data.py

  I have them as:
  data_path = '/home/dave/data/cervic/'
  output_path = '/home/dave/data/cervic/resized/'

  run the script from the terminal:
  python kaggle_convert_input_data.py

  requires python3.5

  The script reads in the input images, attempts to find the largest contour and then crops the image based on the centre of the laregest contour.

  There are 3 images saved for each input image:
  the original image resized to 256x256
  the cropped image resized to 256x256
  the equalised hisotgram of the cropped image resizzed to 256x256

Step #2 - train model
  Use Nvidia Digits:
  create lmdb database, png lossless encoding

  Run Alexnet 2012 architecture:
  ![alt text](/images/Digits_Alexnet2012.png)


Step #3 - test model
  check the data folder path in ./parse_predictions_file/make_test_list.py

  i have it as: 
  test_data_path = '/home/dave/data/cervic/resized/combined/test/'

  run the script from the terminal:
  python make_test_list.py

  this generates a test.txt file. Add this file to the same folder as the test data.

  In Nvidia Digits select the test.txt and select classify many option
  ![alt text](/images/test_file_classifyMany.png)
  
  
  There's no good solution to the next part.... you need to manually copy the predictions to a predictions.txt file - bit of a copy-c and copy-v job... not ideal to be honest
  ![alt text](/images/predictions.png)
  
  run the matlab script that just parses the predictions files in to the bebhionn_submission.csv file that is ready to be combined with the team's predictions for late fusion 
  
  
  
