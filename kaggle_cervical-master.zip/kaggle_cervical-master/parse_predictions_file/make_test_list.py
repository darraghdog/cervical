# -*- coding: utf-8 -*-
"""
Created on Thu May 11 12:49:29 2017

@author: dmonagha
"""

import os, fnmatch

test_data_path = '/home/dave/data/cervic/resized/combined/test/'

test_files = fnmatch.filter(os.listdir(test_data_path), '*.jpg')
for fn in test_files:
    print(fn)
with open('test.txt', 'w') as in_files:
    in_files.writelines(test_data_path + fn + '\n' for fn in test_files)

print('fin')