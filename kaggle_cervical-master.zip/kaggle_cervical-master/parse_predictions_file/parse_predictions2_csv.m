% Dave Monaghan - 1st June 2017 
% parse predictions txt file from Digits

predictions = importfile('predictions.txt');
sorted_predictions = zeros(ceil(size(predictions,1)/3),3);

for ct=2:size(predictions,1)
    current_image_name = strjoin(predictions(ct,2));
    current_image_name = current_image_name(46:end);
    
    checker=1;
    while checker<200
        if ~strcmp(current_image_name(checker),'_')
            current_image_name_temp = current_image_name(1:checker);
        else
            checker = 201;
        end
        checker = checker + 1;
    end
    
    current_image_name = [current_image_name_temp,'.jpg'];
    
    sorted_predictions(str2num(current_image_name_temp)+1,cell2mat(predictions(ct,3))) = sorted_predictions(str2num(current_image_name_temp)+1,cell2mat(predictions(ct,3))) + cell2mat(predictions(ct,4));
    sorted_predictions(str2num(current_image_name_temp)+1,cell2mat(predictions(ct,5))) = sorted_predictions(str2num(current_image_name_temp)+1,cell2mat(predictions(ct,5))) + cell2mat(predictions(ct,6));
    sorted_predictions(str2num(current_image_name_temp)+1,cell2mat(predictions(ct,7))) = sorted_predictions(str2num(current_image_name_temp)+1,cell2mat(predictions(ct,7))) + cell2mat(predictions(ct,8));

end


sorted_predictions = sorted_predictions/300;
sorted_predictions(:,4) = sum(sorted_predictions,2);

for ct=1:size(sorted_predictions,1)
    for check_ct=1:3
        if sorted_predictions(ct,check_ct) < 0.02
            sorted_predictions(ct,check_ct) = 0.02;
        elseif sorted_predictions(ct,check_ct) > 0.96
                sorted_predictions(ct,check_ct) = 0.96;
        end
    end
    sorted_predictions(ct,4) = sum(sorted_predictions(ct,1:3));
    if sorted_predictions(ct,4)~=1
        [a,b] = max(sorted_predictions(ct,1:3));
        sorted_predictions(ct,b) = sorted_predictions(ct,b) - (sorted_predictions(ct,4) - 1);
    end
end

sorted_predictions(:,4) = sum(sorted_predictions(:,1:3),2);
   
fid = fopen('bebhionn_submission.csv','w');
fprintf(fid,'%s\n','image_name,Type_1,Type_2,Type_3')
for ct=1:size(sorted_predictions,1)
    fprintf(fid,'%s\n',[num2str(ct-1),'.jpg,',num2str(sorted_predictions(ct,1)),',',num2str(sorted_predictions(ct,2)),',',num2str(sorted_predictions(ct,3))]);
end
fclose(fid)