# -*- coding: utf-8 -*-
"""
Created on Thu May 11 12:49:29 2017

@author: dmonagha
"""

import cv2
import numpy as np
import math
import os, fnmatch
import progressbar, time
from shutil import copyfile
from pathlib import Path

data_path = '/home/dave/data/cervic/'
output_path = '/home/dave/data/cervic/resized/'

output_dir_structure = ['cropped_and_hist_equ/',
                        'cropped/',
                        'original/',
                        'combined/',
                        'check_images/'
                        ]

data_sub_folder = [
                  'train/Type_1/',
                  'train/Type_2/',
                  'train/Type_3/',
                  'test/'
                  ]

def resize_kaggle_data(input_dir_list, data_path, data_sub_folder, output_path, output_dir_structure, 
                       rows=256,cols=256,contour_threshold=25,inner_rect_factor=0.75,save_check_images=True):
    
    bar = progressbar.ProgressBar()
    for item in bar(input_dir_list):
        current_file2_check = Path(output_path + output_dir_structure[2] + data_sub_folder + item[0:-4] + '_' + output_dir_structure[2][0:-1] + '.jpg')
        if current_file2_check.exists():         
            print(' File ' + item + ' already processed')
        else:
            try:
                 
                # read in the image in rgb and then convert to gray and yuv
                img_rgb = cv2.imread(data_path + data_sub_folder + item,1)
                # save a placeholder so that other instances jump this image
                cv2.imwrite(output_path + output_dir_structure[2] + data_sub_folder + item[0:-4] + '_' + output_dir_structure[2][0:-1] + '.jpg', img_rgb)

                img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2GRAY)
        
                ret,img_thresholded = cv2.threshold(img_gray,contour_threshold,255,cv2.THRESH_BINARY)
                img_thresholded_back2RGB = cv2.cvtColor(img_thresholded,cv2.COLOR_GRAY2RGB)
    
                areaArray = []
    
                _, contours, _ = cv2.findContours(img_thresholded, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                for i, c in enumerate(contours):
                    area = cv2.contourArea(c)
                    areaArray.append(area)
                    areaLargest = np.argmax(areaArray)
                    
                areaLargestCnt = contours[areaLargest]
                x, y, w, h = cv2.boundingRect(areaLargestCnt)
                (x_min_cir,y_min_cir),radius_min_cir = cv2.minEnclosingCircle(areaLargestCnt)
                areaLargestMax_i = areaLargest
                
                inner_cube_half_length = (radius_min_cir * (math.sin(45))) * inner_rect_factor
                x_new = math.floor(x_min_cir -(inner_cube_half_length) )
                y_new = math.floor(y_min_cir -(inner_cube_half_length) )
                w_new = math.floor(inner_cube_half_length * 2)
                h_new = math.floor(inner_cube_half_length * 2)
                
                if x_new < 0:
                    y_new = y_new - x_new
                    w_new = w_new + (x_new * 2)
                    h_new = h_new + (x_new * 2)
                    x_new = 0
                if y_new < 0:
                    x_new = x_new - y_new
                    w_new = w_new + (y_new * 2)
                    h_new = h_new + (y_new * 2)
                    y_new = 0    
    
                crop_img = img_rgb[y_new: y_new + h_new, x_new: x_new + w_new] # Crop from x, y, w, h -> 100, 200, 300, 400
                
                img_yuv = cv2.cvtColor(crop_img, cv2.COLOR_BGR2YUV)
                # equalize the histogram of the Y channel
                img_yuv[:,:,0] = cv2.equalizeHist(img_yuv[:,:,0])
                
                # convert the YUV image back to RGB format
                crop_img_histEqualised = cv2.cvtColor(img_yuv, cv2.COLOR_YUV2BGR)
                img_histEqualised = img_rgb.copy()
                img_histEqualised[y_new: y_new + h_new, x_new: x_new + w_new] = crop_img_histEqualised
    
                crop_img_histEqualised = img_histEqualised[y_new: y_new + h_new, x_new: x_new + w_new] # Crop from x, y, w, h -> 100, 200, 300, 400
                
                resized_crop_img_histEqualised = cv2.resize(crop_img_histEqualised, (rows, cols), interpolation = cv2.INTER_LANCZOS4)
                resized_crop_img_rgb = cv2.resize(crop_img, (rows, cols), interpolation = cv2.INTER_LANCZOS4)
                resized_img_rgb = cv2.resize(img_rgb, (rows, cols), interpolation = cv2.INTER_LANCZOS4)
                
                cv2.imwrite(output_path + output_dir_structure[0] + data_sub_folder + item[0:-4] + '_' + output_dir_structure[0][0:-1] + '.jpg', resized_crop_img_histEqualised)
                copyfile(output_path + output_dir_structure[0] + data_sub_folder + item[0:-4] + '_' + output_dir_structure[0][0:-1] + '.jpg',
                output_path + output_dir_structure[3] + data_sub_folder + item[0:-4] + '_' + output_dir_structure[0][0:-1] + '.jpg')
                
                cv2.imwrite(output_path + output_dir_structure[1] + data_sub_folder + item[0:-4] + '_' + output_dir_structure[1][0:-1] + '.jpg', resized_crop_img_rgb)
                copyfile(output_path + output_dir_structure[1] + data_sub_folder + item[0:-4] + '_' + output_dir_structure[1][0:-1] + '.jpg',
                output_path + output_dir_structure[3] + data_sub_folder + item[0:-4] + '_' + output_dir_structure[1][0:-1] + '.jpg')

                cv2.imwrite(output_path + output_dir_structure[2] + data_sub_folder + item[0:-4] + '_' + output_dir_structure[2][0:-1] + '.jpg', resized_img_rgb)
                copyfile(output_path + output_dir_structure[2] + data_sub_folder + item[0:-4] + '_' + output_dir_structure[2][0:-1] + '.jpg',
                output_path + output_dir_structure[3] + data_sub_folder + item[0:-4] + '_' + output_dir_structure[2][0:-1] + '.jpg')
  
            except:
                print(' Failed on image' + item)
            if save_check_images:
                try:
                    
                    cv2.drawContours(img_thresholded_back2RGB, contours, areaLargestMax_i, (0, 0, 255), 20)
                    cv2.rectangle(img_thresholded_back2RGB, (x, y), (x+w, y+h), (0,255,0), 20)
                    
                    img_histEqualised_draw = img_histEqualised.copy()
                    cv2.rectangle(img_thresholded_back2RGB, (x_new, y_new), (x_new+w_new, y_new+h_new), (255,0,0), 20)
                    cv2.drawContours(img_histEqualised_draw, contours, areaLargestMax_i, (0, 0, 255), 20)
                    cv2.rectangle(img_histEqualised_draw, (x_new, y_new), (x_new+w_new, y_new+h_new), (255,0,0), 20)
                    
                    cv2.putText(img_rgb,"Original Image", (120,120), cv2.FONT_HERSHEY_SIMPLEX, 5,(255,255,255),10)
                    cv2.putText(img_thresholded_back2RGB,"Detected Contours", (120,120), cv2.FONT_HERSHEY_SIMPLEX, 5,(0,0,255),10)
                    cv2.putText(img_histEqualised,"Equalised Histogram", (120,120), cv2.FONT_HERSHEY_SIMPLEX, 5,(255,255,255),10)
                    cv2.putText(img_histEqualised_draw,"Cropped Area", (120,120), cv2.FONT_HERSHEY_SIMPLEX, 5,(255,255,255),10)
                    cv2.putText(resized_img_rgb,"Resized Original", (10,15), cv2.FONT_HERSHEY_SIMPLEX, 0.6,(255,255,255),1)
                    cv2.putText(resized_crop_img_rgb,"Resized Original Cropped", (10,15), cv2.FONT_HERSHEY_SIMPLEX, 0.6,(255,255,255),1)
                    cv2.putText(resized_crop_img_histEqualised,"Resized HistoEqu Cropped", (10,15), cv2.FONT_HERSHEY_SIMPLEX, 0.6,(255,255,255),1)
                    res1 = np.vstack((img_rgb,img_thresholded_back2RGB)) #stacking images side-by-side
                    res2 = np.vstack((img_histEqualised,img_histEqualised_draw)) #stacking images side-by-side
                    res3 = np.vstack((resized_img_rgb,resized_crop_img_rgb,resized_crop_img_histEqualised)) #stacking images on top of each other
                    
                    new_rows = img_rgb.shape[0]*2
                    new_cols = math.floor((img_rgb.shape[0]*2)/3)
                    res3 = cv2.resize(res3, (new_cols, new_rows), interpolation = cv2.INTER_CUBIC)
                    border = math.floor((img_rgb.shape[1] - math.floor((img_rgb.shape[0]*2)/3))/2)
                    res3_border = cv2.copyMakeBorder(res3, top=0, bottom=0, left=border, right=border, borderType= cv2.BORDER_CONSTANT, value=[0,0,0] )

                    res_final = np.hstack((res1,res2,res3_border))
                    res_final = cv2.resize(res_final, (0,0), fx=0.25, fy=0.25) 
                    cv2.imwrite(output_path + output_dir_structure[4] + item, res_final)
                    
                except:
                    print(' Couldnt write check image for file ' + item)
        time.sleep(0.1)



#make the output directories
for output_dir in output_dir_structure:
    if output_dir == 'check_images/':
        if not os.path.exists(output_path + output_dir):
            os.makedirs(output_path + output_dir) 
            output_dir
    else:
        if not os.path.exists(output_path + output_dir):
            os.makedirs(output_path + output_dir)
        for sub_folder_dir in data_sub_folder:
            if not os.path.exists(output_path + output_dir + sub_folder_dir):
                os.makedirs(output_path + output_dir + sub_folder_dir)
  
    
for sub_folder_dir in data_sub_folder:
    print(sub_folder_dir)
    input_dir_list = fnmatch.filter(os.listdir( data_path + sub_folder_dir), '*.jpg')
    resize_kaggle_data(input_dir_list, data_path, sub_folder_dir, output_path, output_dir_structure,
                       rows=256,cols=256,contour_threshold=75,inner_rect_factor=0.8,save_check_images=False)

    











