
# Convert the output from DIGITS GUI to predictions in format for Kaggle competition

input_file = 'alexnet_large_256_circle_scale_crop.txt'
output_file = input_file.rstrip('.txt') + '.csv'

type_index_lookup = {'Type 1': 0, 'Type 2': 1, 'Type 3': 3}

with open(input_file) as f:
	with open(output_file, 'w') as fo:
		fo.write('image_name,Type_1,Type_2,Type_3')
		
		for line in f.readlines():
			fo.write('\n')
			elements = line[0:-1].split('\t')
			
			im_name = elements[1].split('/')[-1]
			
			type_acc_lookup = {}
			
			type_acc_lookup[elements[2]] = float(elements[3].rstrip('%'))/100
			type_acc_lookup[elements[4]] = float(elements[5].rstrip('%'))/100
			type_acc_lookup[elements[6]] = float(elements[7].rstrip('%'))/100
			

			line_str = im_name + ',' + str(type_acc_lookup['Type 1']) + ',' + str(type_acc_lookup['Type 2']) + ',' + str(type_acc_lookup['Type 3'])
			print line
			print line_str

			fo.write(line_str)
	
