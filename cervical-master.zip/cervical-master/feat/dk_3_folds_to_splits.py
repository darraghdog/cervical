

folds_dir = 'folds_scaled'
splits_dir = 'splits_scaled'
# To get:
# splits_scaled/split0/class1/*.jpg

file_copy_limit = 1  # limit of 10 files per split dir or all if None

import os
from copy import deepcopy
from shutil import copyfile

def copy_files_from_fold_dir_to_splits_dirs(train_fold, set_type, dst_split_dir):

    src_fold_dir = os.path.join(folds_dir, train_fold)
    src_fold_dir_classes = os.listdir(src_fold_dir)

    for class_label in src_fold_dir_classes:

        dst_split_type_dir = os.path.join(dst_split_dir, set_type)

        dst_split_type_label_dir = os.path.join(dst_split_type_dir, class_label)
        # dst_split_label_dir = os.path.join(dst_split_dir, class_label)

        src_fold_label_dir = os.path.join(src_fold_dir, class_label)
        print src_fold_label_dir, '->', dst_split_type_label_dir

        if not os.path.exists(dst_split_type_label_dir):
            os.makedirs(dst_split_type_label_dir)

        to_copy_files = os.listdir(src_fold_label_dir)

        # Copy only some files during development
        if file_copy_limit is not None:
            to_copy_files = to_copy_files[0:file_copy_limit]

        print to_copy_files

        for file_to_copy in to_copy_files:
            copyfile(os.path.join(src_fold_label_dir, file_to_copy),
                     os.path.join(dst_split_type_label_dir, file_to_copy)
                     )

folds_dir_names = os.listdir(folds_dir)

splits_folds_lookup = {}

for i in range(0, len(folds_dir_names)):
    splits_folds_lookup['split'+str(i)] = deepcopy(folds_dir_names)
    # shift list of directories one to the left:
    folds_dir_names.append(folds_dir_names.pop(0))

# print splits_folds_lookup

if not os.path.exists(splits_dir):
    os.makedirs(splits_dir)

for split_dir, folds_list in splits_folds_lookup.iteritems():
    # splits_scaled/split0/class1/*.jpg
    # =
    # splits_dir/split_dir/dir_in_fold_dir/*.jpg
    print split_dir, ':', folds_list

    train_folds_dirs = folds_list[0:-1]
    val_folds_dirs = folds_list[-1]
    print 'train fold dirs:', train_folds_dirs, 'val fold dir:', val_folds_dirs

    dst_split_dir = os.path.join(splits_dir, split_dir)
    if not os.path.exists(dst_split_dir):
        os.makedirs(dst_split_dir)

    for train_fold in train_folds_dirs:
        print train_fold
        set_type = 'train'

        copy_files_from_fold_dir_to_splits_dirs(train_fold, set_type, dst_split_dir)

    set_type = 'validation'
    copy_files_from_fold_dir_to_splits_dirs(val_folds_dirs, set_type, dst_split_dir)

