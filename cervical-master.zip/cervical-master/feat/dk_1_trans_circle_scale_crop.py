

# Detect circle
# crop to that circle if the diameter is larger than some proportion of the image dimension
# crop the image to be square, or bounce circle back onto image and crop around image
# scale the image to 256x256

src_dir = 'train'
dst_dir = 'train_circle_scale_crop'

src_dir = 'train_large'
dst_dir = 'train_large_circle_scale_crop'


# src_dir = 'test'
# dst_dir = 'test_circle_scale_crop'

import os
import cv2
import numpy as np

draw_all = False
draw_chosen = False
resize = True
image_edge_pixels = 256
im_per_class_lim = None  # None or some number

# print cv2.getBuildInformation()

if not os.path.exists(dst_dir):
    os.makedirs(dst_dir)

for subdir, dirs, files in os.walk(src_dir):
    dst_subdir = dst_dir + subdir.lstrip(src_dir)
    if not os.path.exists(dst_subdir):
        os.makedirs(dst_subdir)

    im_per_class = 0
    for file in files:
        file_name = os.path.join(subdir, file)

        if file.endswith('.jpg'):
            img = cv2.imread(file_name)
            # print img.shape
            # cv2.imshow('tmp', img)

            dst_file_name = os.path.join(dst_subdir, file)
            print file_name
            print dst_file_name

            tmp_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            tmp_img = cv2.medianBlur(tmp_img, 7)

            # circles = cv2.HoughCircles(tmp_img, cv2.HOUGH_GRADIENT, 1, 20,
            #                            param1=50, param2=100, minRadius=500)
            height, width = img.shape[:2]
            print img.shape
            # circles = cv2.HoughCircles(tmp_img, cv2.HOUGH_GRADIENT, 1, 10, np.array([]), 100, 30,
            #                            minRadius=min(height, width)/4,
            #                            maxRadius=max(height, width))

            circles = cv2.HoughCircles(tmp_img, cv2.HOUGH_GRADIENT, dp=1, minDist=20, param1=100, param2=15,
                                       minRadius=min(height, width)/5,
                                       maxRadius=int(min(height, width)*0.5))

            # print circles

            chosen_circle = None

            if circles is not None:  # Check if circles have been found and only then iterate over these and add them to the image
                a, b, c = circles.shape
                if draw_all:
                    for i in range(b):
                        cv2.circle(img, (circles[0][i][0], circles[0][i][1]), circles[0][i][2], (0, 0, 255), 3,
                                   cv2.LINE_AA)
                        cv2.circle(img, (circles[0][i][0], circles[0][i][1]), 2, (0, 255, 0), 3,
                                   cv2.LINE_AA)  # draw center of circle

                # Get the largest circle only:
                largest_i = np.argmax(circles[0,:,2])
                chosen_circle = circles[:, largest_i, :]

                if draw_chosen:
                    cv2.circle(img, (chosen_circle[0][0], chosen_circle[0][1]), chosen_circle[0][2], (0, 255, 0), 10,
                                   cv2.LINE_AA)


            # print cv2.imwrite(dst_file_name, cv2.medianBlur(img, 5))

            if resize:
                if chosen_circle is not None:
                    # bounce the bounding box back on screen if it goes off:

                    print chosen_circle
                    size_lim = min(height, width)
                    print (height, width)
                    height_bounds = np.array([chosen_circle[0][1]-chosen_circle[0][2], chosen_circle[0][1]+chosen_circle[0][2]])
                    width_bounds = np.array([chosen_circle[0][0] - chosen_circle[0][2], chosen_circle[0][0] + chosen_circle[0][2]])


                    # make sure height bounds are above 0:
                    height_bounds = height_bounds - min(0, height_bounds[0])
                    # make sure height bounds are below box size:
                    height_bounds = height_bounds + min(0, height - height_bounds[1])

                    # make sure width bounds are above 0:
                    width_bounds = width_bounds - min(0, width_bounds[0])
                    # make sure height bounds are below box size:
                    width_bounds = width_bounds + min(0, width - width_bounds[1])

                    print height_bounds
                    print width_bounds

                    cropped_img = img[int(np.ceil(int(height_bounds[0]))): int(np.floor(height_bounds[1])),
                                  int(np.ceil(width_bounds[0])): int(np.floor(width_bounds[1])), :]

                else:
                    # Square the image to the smallest dimension:
                    square_dim = min(height, width)
                    height_offset = 0
                    if height > square_dim:
                        height_offset = int((height-square_dim)/2)
                    width_offset = 0
                    if width > square_dim:
                        width_offset = int((width-square_dim)/2)
                    cropped_img = img[0+height_offset: -height_offset-1, 0+width_offset: -width_offset-1, :]

                cropped_resized_img = cv2.resize(cropped_img, (image_edge_pixels, image_edge_pixels), cv2.INTER_AREA)
                print cv2.imwrite(dst_file_name, cropped_resized_img)
            else:
                print cv2.imwrite(dst_file_name, img)

            im_per_class += 1

            if im_per_class >= im_per_class_lim and im_per_class_lim is not None:
                break
