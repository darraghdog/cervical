


src_dir = 'train_large'
dst_dir = 'folds_scaled'

import os
import cv2
import numpy as np

num_folds = 5
image_edge_pixels = 256
im_per_class_lim = None  # None or some number


# to enable round-robin fold assignment:
files_copied = 0

if not os.path.exists(dst_dir):
    os.makedirs(dst_dir)

# create fold-num directories
for fold in range(0, num_folds):
    fold_dir = os.path.join(dst_dir, str(fold))
    if not os.path.exists(fold_dir):
        os.makedirs(fold_dir)

for subdir, dirs, files in os.walk(src_dir):

    im_per_class = 0
    for file in files:
        print '--'

        file_name = os.path.join(subdir, file)
        print file_name

        if file.endswith('.jpg'):
            img = cv2.imread(file_name)
            # Copies from: "train_large/Type_1/"
            # To: "folds_scaled/n/Type_1/" where n is decided by round-robin per image
            # dst_file = dst_dir + '/' + str(files_copied % num_folds) + '/' + subdir.lstrip(src_dir+'/')
            # i.e. fold number is calculated using modulus of a files copied counter
            dst_file_dir = os.path.join(dst_dir, str(files_copied % num_folds), subdir.lstrip(src_dir+'/'))
            dst_file = os.path.join(dst_file_dir, file)

            if not os.path.exists(dst_file_dir):
                os.makedirs(dst_file_dir)

            print file, subdir
            print dst_file

            height, width = img.shape[:2]

            # Square the image to the smallest dimension:
            square_dim = min(height, width)
            height_offset = 0
            if height > square_dim:
                height_offset = int((height - square_dim) / 2)
            width_offset = 0
            if width > square_dim:
                width_offset = int((width - square_dim) / 2)
            cropped_img = img[0 + height_offset: -height_offset - 1, 0 + width_offset: -width_offset - 1, :]

            cropped_resized_img = cv2.resize(cropped_img, (image_edge_pixels, image_edge_pixels), cv2.INTER_AREA)
            print cv2.imwrite(dst_file, cropped_resized_img)

            files_copied += 1

            im_per_class += 1
            if im_per_class >= im_per_class_lim and im_per_class_lim is not None:
                break