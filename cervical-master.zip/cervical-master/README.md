# Cervical Cancer Detection (@Kaggle @Intel)

Directory Structure to set up locally
```
features/
data/
   --- Type_1/
   --- Type_2/
   --- Type_3/
   --- train/Type_1/
   --- train/Type_2/
   --- train/Type_3/
scripts/
   ---log/checkpoint01/
   ---log/checkpoint02/
   ---log/checkpoint03/
   ---log/checkpoint04/
   ---log/checkpoint05/
   ---log/checkpoint06/
   --- etc...
```
